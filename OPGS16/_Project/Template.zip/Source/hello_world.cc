
#include "../Include/hello_world.h"

void SceneFirstHelloWorld::Initiate() {
  SetBackgroundColor(opgs16::DColor::Magenta);
}